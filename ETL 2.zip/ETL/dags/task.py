from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from sentence_transformers import SentenceTransformer
from pinecone import Pinecone
import psycopg2
import os
import decimal
import json

# === ENVIRONMENT CONFIG ===
SUPABASE_DB_URL = os.getenv("SUPABASE_DB_URL")
PINECONE_API_KEY = os.getenv("PINECONE_API_KEY")
PINECONE_INDEX_NAME = "socgen"
PINECONE_NAMESPACE = "example-namespace"

pc = Pinecone(api_key=PINECONE_API_KEY)

# === 1. Collect from Supabase ===
def collect_iocs():
    conn = psycopg2.connect(SUPABASE_DB_URL)
    cur = conn.cursor()
    cur.execute("""
        SELECT id, type, value, description, confidence, severity, tags, sources,
               first_seen, last_seen, is_active, metadata
        FROM iocs
        WHERE is_active = true
        ORDER BY updated_at DESC
        LIMIT 100
    """)
    rows = cur.fetchall()
    cur.close()
    conn.close()

    result = []
    for row in rows:
        result.append({
            "id": row[0],
            "type": row[1],
            "value": row[2],
            "description": row[3],
            "confidence": row[4],
            "severity": row[5],
            "tags": row[6],
            "sources": row[7],
            "first_seen": str(row[8]),
            "last_seen": str(row[9]),
            "is_active": row[10],
            "metadata": row[11],
        })
    return result

# === 2. Format threat entries ===
def format_ioc(entry):
    # Safely parse JSON fields
    tags = entry.get("tags")
    if isinstance(tags, str):
        try:
            tags = json.loads(tags)
        except Exception:
            tags = []

    sources = entry.get("sources")
    if isinstance(sources, str):
        try:
            sources = json.loads(sources)
        except Exception:
            sources = []

    # Default values
    if not isinstance(tags, list):
        tags = []

    if not isinstance(sources, list):
        sources = []

    # Format strings
    tags_str = ", ".join(tags) if tags else "no tags"
    sources_str = ", ".join([s.get("name", "") for s in sources if isinstance(s, dict)]) if sources else "unknown source"

    return (
        f"{entry['type']} IOC with value {entry['value']} was first seen on {entry['first_seen']} and last seen on {entry['last_seen']}. "
        f"Severity is {entry['severity']}, confidence is {entry['confidence']}. "
        f"Description: {entry['description']}. Tags: {tags_str}. Sources: {sources_str}."
    )
# === 3. Embed ===
def generate_embeddings(entries):
    model = SentenceTransformer("all-MiniLM-L6-v2")
    texts = [format_ioc(entry) for entry in entries]
    embeddings = model.encode(texts)
    return embeddings

# === 4. Store in Pinecone ===
def store_in_pinecone(embeddings, entries):
    try:
        index = pc.Index(PINECONE_INDEX_NAME)
        print(f"✅ Pinecone index loaded: {PINECONE_INDEX_NAME}")

        vectors = []
        for entry, emb in zip(entries, embeddings):
            confidence_val = entry["confidence"]
            if isinstance(confidence_val, decimal.Decimal):
                confidence_val = float(confidence_val)

            vectors.append({
                "id": str(entry["id"]),
                "values": emb.tolist(),
                "metadata": {
                    "type": entry["type"],
                    "value": entry["value"],
                    "severity": entry["severity"],
                    "confidence": confidence_val,
                    "tags": json.dumps(entry["tags"]),
                    "first_seen": entry["first_seen"],
                    "last_seen": entry["last_seen"]
                }
            })

        print(f"🔄 Upserting {len(vectors)} vectors to Pinecone...")
        index.upsert(vectors=vectors, namespace=PINECONE_NAMESPACE)
        print("✅ Upsert completed successfully.")

    except Exception as e:
        print("❌ Error during Pinecone upsert:")
        print(e)
        raise

# === 5. Full ETL wrapper ===
def ioc_etl():
    data = collect_iocs()
    if not data:
        print("No active IOCs found.")
        return
    embeddings = generate_embeddings(data)
    store_in_pinecone(embeddings, data)

# === DAG CONFIG ===
default_args = {
    "owner": "airflow",
    "depends_on_past": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=10),
}

with DAG(
    dag_id="supabase_ioc_to_pinecone_etl",
    default_args=default_args,
    description="ETL DAG to fetch threat IOCs from Supabase and index into Pinecone",
    schedule_interval=timedelta(days=1),
    start_date=datetime(2023, 1, 1),
    catchup=False,
) as dag:

    etl_task = PythonOperator(
        task_id="run_ioc_etl",
        python_callable=ioc_etl,
    )

    etl_task